# engineer

Wiem, że w pracy znajduje się jeszcze bardzo dużo błędów ortograficznych, interpunkcyjnych, fonetycznych, fleksyjnych, składniowych, leksykalnych i stylistycznych. Będą one stopniowo wyłapywane i na bieżąco poprawiane.
